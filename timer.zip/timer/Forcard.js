import * as React from 'react';



export default function Forcard(props){

return(
  <div>
<div>{props.name}</div>
<div>{props.comm}</div>
<p></p>
</div>
);


}