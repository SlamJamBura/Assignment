import * as React from 'react';
import { Text, View, StyleSheet } from 'react-native';
import Constants from 'expo-constants';
import Forcard from "./Forcard"
import {useState} from "react";
import {useEffect} from "react";
import {Button} from 'react-native';



import AssetExample from './components/AssetExample';


import { Card } from 'react-native-paper';

export default function App (){
/* const [count,setCount] = useState(0); 
    const incrementFunc = () =>{
        setTimeout(setCount(count +1 ),1000);
    }
    useEffect(()=>{
      
        console.log("called at mounting time");
    const k=setTimeout(incrementFunc,1000);
    },)
    return (<>
        <Text> Count: {count} </Text>
        <Button title='Start Increment' onPress={incrementFunc}></Button>
        <Button title='Reset to 0' onPress={()=>{
           clearTimeout(k,1000);
           setCount(0);
            console.log("count :"+count);
        }}></Button>
        <Button title='Stop Increment' onPress={()=>{
            console.log(">>  clear Interval");
            clearTimeout(k,10);
        }}></Button>
    </>);
*/
   const [count,setCount] = useState(0); 
    const [intervalId,setIntervalId] = useState(0);
    
    const incrementFunc = () =>{
        
        setCount(count=>(count+1) ); 
        console.log("count:"+count);
    }
    const startCounter = () =>{
        stopCounter();
        setIntervalId(setInterval(incrementFunc,1000));
    }
    const stopCounter = () =>{
        clearInterval(intervalId);
    }

    useEffect(()=>{
        console.log("called at mounting time");
        startCounter();
    },[])
    return (<>
        <Text> Count: {count} </Text>
        <Button title='Start Timer' onPress={startCounter}></Button>
        <Button title='Reset to 0' onPress={()=>{
            setCount(0);
            console.log("count :"+count);
        }}></Button>
        <Button title='Stop Timer' onPress={stopCounter}></Button>
    </>);
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});
