
const customerApiEndPoint = 'https://nodeapi.pyther.com/customer';

export const getCustomers = async () =>{
    // fetch return promise
  return fetch(customerApiEndPoint).
  then(response => response.json())
  .then(data => (data))
  .catch((error) => {
  console.error('Error:', error);
  });
};

  export const deleteCustomer = async (id)=>{
    return fetch(customerApiEndPoint +"/"+id, {
        method: 'DELETE', // or 'PUT'
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({id}),
        })
        .then(response => response.json())
        .then(data => {
            return data;
        })
        .catch((error) => {
            console.error('Error:', error);
        });
  };
  export const getCustomerById = async (id) =>{
    return fetch(customerApiEndPoint +"/"+id, {
        method: 'GET', // or 'PUT'
        headers: {
            'Content-Type': 'application/json',
        }
        })
        .then(response => response.json())
        .then(data => {
            return data;
        })
        .catch((error) => {
            console.error('Error:', error);
        });
  }
  export const addCustomer = async (customer) =>{
    return fetch(customerApiEndPoint, {
        method: 'POST', // or 'PUT'
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(customer),
        })
        .then(response => response.json())
        .then(data => {
            return data;
        })
        .catch((error) => {
            console.error('Error:', error);
        });
  }

  export const updateCustomer = async (customer) =>{
    return fetch(customerApiEndPoint, {
        method: 'PUT', // or 'PUT'
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(customer),
        })
        .then(response => response.json())
        .then(data => {
            return data;
        })
        .catch((error) => {
            console.error('Error:', error);
        });
  }

