let customers  = [
    {
      id: "bd7acbea-c1b1-46c2-aed5-3ad53abb28ba",
      name: "First Item",
      email: "vivek@pyther.com",
      address: "India",
      phone:'9724232340'
    },
    {
      id: "3ac68afc-c605-48d3-a4f8-fbd91aa97f63",
      name: "Vivek",
      email: "vivek@pyther.com",
      address: "India",
      phone:'9724232340'
    },
    {
      id: "58694a0f-3da1-471f-bd96-145571e29d72",
      name: "Rama",
      email: "vivek@pyther.com",
      address: "India",
      phone:'9724232340'
    }
  ];

  export const deleteCustomer = (id)=>{
   customers = customers.filter((record)=>(record.id != id));
  };
  export const getCustomers = ()=>(customers);
  export const addCustomer = (customer) =>{
    customers.unshift(customer);
  }
  export const getCustomerById = (id) =>{
    let list = customers.filter((record)=>(record.id == id));
    if(list.length > 0){
        return list[0];
    }
  }
  export const updateCustomer = (customer) =>{
    console.log(">> updateCustomer ...",customer);
    let list = customers.filter((record)=>(record.id === customer.id));
    console.log(">> if updateCustomer ..."+list.length);
    if(list.length > 0){
        console.log(">> if updateCustomer ...");
        let record = list[0];
        let {name,email,phone,address} = customer;
        record.name = name;
        record.email = email;
        record.phone = phone;
        record.address = address;
    }else{
        console.log(">> else updateCustomer ...");
    }
  }

