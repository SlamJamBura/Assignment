import axios from 'axios';

// yarn add axios
let serviceEndPoint = "https://nodeapi.pyther.com/customer";

export const getCustomers = async ()  => {
       let result = await axios.get(serviceEndPoint);
        return result.data;
}
export const addCustomer = async (customer) => {
    let result = await axios.post(serviceEndPoint,customer);
    return result.data;
}
export const getCustomerById = async (customerId)  => {
    let result = await axios.get(serviceEndPoint+"/"+customerId);
    return result.data;
}

export const deleteCustomer = async (customerId)  => {
    let result = await axios.delete(serviceEndPoint+"/"+customerId);
    return result.data;
}

export const updateCustomer = async(customer) => {
    let result = await axios.put(serviceEndPoint,customer);
    return result.data;
}