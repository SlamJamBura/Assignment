import {Text,Button} from 'react-native';
import React,{useEffect, useState} from 'react';

export const Counter = ()=>{
    const [count,setCount] = useState(0); //initial Value
    const [intervalId,setIntervalId] = useState(0);
    //count is mapped to render <Counter/> 
    const incrementFunc = () =>{
        //setCount(count +1 );
        //setCount(count+1); // directly setting value
        setCount((count) => {return (count+1)});
        //setCount(count => (count+1)); //this line will reload Counter
        console.log("count:"+count);
    }
    const startCounter = () =>{
        stopCounter();
        setIntervalId(setInterval(incrementFunc,1000));
    }
    const stopCounter = () =>{
        clearInterval(intervalId);
    }

    //useEffect will be called when ever there is a change 
    // given on configured array argument
    // will surely call on mount time

    // useEffect has two argument
    // 1: funciton 2:[]
    useEffect(()=>{
        console.log("called at mounting time:"+count);
        startCounter();
    },[])
    return (<>
        <Text> Count: {count} </Text>
        <Button title='Start Timer' onPress={startCounter}></Button>
        <Button title='Reset to 0' onPress={()=>{
            setCount(0);
            console.log("count :"+count);
        }}></Button>
        <Button title='Stop Timer' onPress={stopCounter}></Button>
    </>);
}
