import React from 'react';
import { StyleSheet, TextInput, View, SafeAreaView, Text, Alert, TouchableHighlight, TouchableOpacity, Button,Image } from 'react-native';
import { useNavigation } from "@react-navigation/native"
import ReactFragment from "react-native"

const Menu = () => {
    let navigation = useNavigation();
    // can we use useNavigation in Class Component ?

    return(
     <View>
        <View style={{flexDirection:"row",position:"absolute",marginTop:0,}}  >
            <Button onPress={() => navigation.navigate('Home')} title="Home" ></Button>
            <Button onPress={() => navigation.navigate('Shirts')} title="Shirts" ></Button>
            <Button onPress={() => navigation.navigate('Customer')} title="Customer"></Button>
            <Button onPress={() => navigation.navigate('Login')} title="Logout"></Button>
            <Button title="Bonus" > </Button>
       
        </View>
        
        </View>
    );
    }

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    marginHorizontal: 16,
  },
  button: {
    alignItems: "center",
    backgroundColor: "#DDDDDD",
    padding: 10
  },
  opacity: {
    alignItems: "center",
    backgroundColor: "#737373",
    padding: 10
  },
  title: {
    textAlign: 'center',
    marginVertical: 8,
  },
  fixToText: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  separator: {
    marginVertical: 8,
    borderBottomColor: '#737373',
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
 
});

export default Menu;
