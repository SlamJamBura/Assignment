import React from "react";
import { StyleSheet, Text, View, Image,TouchableOpacity } from "react-native";

const Candle = ({color,deleteRecord}) => {
  //color and deleteRecord are called Props
  // color is string
  // deleteRecord is function
  return (
    <View
    style={{
      width:'100%',height:80
    }}>
        <View style={[styles.container, {
        // Try setting `flexDirection` to `"row"`.
        flexDirection: "row"
        }]}>
        <View style={{ flex: 7, backgroundColor: color }} />
        <View style={{ flex: 1 }} >
            <TouchableOpacity onPress={deleteRecord}>
            <Image style={{height: 40, width: 30}} 
                source={{uri: "https://img.icons8.com/color/96/000000/delete-forever.png"}}/>
            </TouchableOpacity>
        </View>
        </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
});

export default Candle;