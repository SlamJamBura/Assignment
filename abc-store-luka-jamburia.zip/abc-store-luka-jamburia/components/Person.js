import {Text} from 'react-native';
import React, { Children } from 'react';
const header = <Text> Person</Text>

export class PersonC extends React.Component{
    constructor(props){
        state.title ="Hello ";
        
        super(props);
        console.log(">>constructor");
    }
    
   
    componentDidMount(){ 
        console.log(">>componentDidMount");
        var i =90; 
    }
    UNSAFE_componentWillMount(){
        console.log(">>UNSAFE_componentWillMount");
    }

    componentWillUnmount(){
        console.log(">>componentWillUnmount");
    }
    render(){
        console.log(">>render");
        return (
            <>
                <Text> Person Class Comp</Text>
                <Text>{this.props.name}::{this.props.email}</Text>
            </>)
    }
}

export default function Person (props){ 
    return (
    <>
        {header}
        {props.Childrenchildren}
        <Text>{props.name}::{props.email}</Text>
    </>)
}

export function PersonX ({children,name,email}){ //destructure
    return (
    <>
        {header}
        {children}
        <Text>{name}::{email}</Text>
    </>)
}