import React, { useEffect, useState } from 'react';
import { Text, TextInput, StyleSheet, TouchableOpacity,  View } from 'react-native';

const defaultCustomer = {
    id:0,
    name:'',
    email:'',
    phone:'',
    address:''
};
export const CustomerAdd = ({addUpdateItem,selectCustomer}) => {
    console.log("selectCustomer ",selectCustomer);
    const [customer,setCustomer] = useState({...defaultCustomer})
    const [addLabel,setAddLabel] = useState("Add Customer");
    useEffect(()=>{
        let customerParam = defaultCustomer;
        if(selectCustomer != null){
            customerParam = {...selectCustomer};
            setAddLabel("Update Customer")
        }else{
            setAddLabel("Add Customer")
        }
            setCustomer({...customerParam} );
            
    },[selectCustomer]);
    return (
    <View>
      <Text> Customer Form </Text>
      <TextInput
        placeholder='Name'
        value={customer.name}
        onChangeText={(name)=>{
            console.log("val:"+name)
            setCustomer({...customer,name})
        }}
        style={styles.input}
      />
      <TextInput
        placeholder='Email'
        value={customer.email}
        onChangeText={(email)=>{
            setCustomer({...customer,email})
        }}
        style={styles.input}
      />
      <TextInput
        placeholder='Phone'
        value={customer.phone}
        onChangeText={(phone)=>{
            setCustomer({...customer,phone})
        }}
        style={styles.input}
      />
        <TextInput
        placeholder='Address'
        value={customer.address}
        onChangeText={(address)=>{
            setCustomer({...customer,address})
        }}
        style={styles.input}
      />
      <TouchableOpacity style={
          {alignItems:'center',margin:8,padding:8, marginLeft:'20%',marginRight:'20%',
      backgroundColor:'lightblue'}} onPress={()=>{
        addUpdateItem(customer);
        setCustomer({...defaultCustomer});
        setAddLabel("Add Customer");
        console.log("Add Customer ");

      }}>
          <Text style={{fontSize:20}} >{addLabel}</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
    input: {
      height: 40,
      margin: 12,
      borderWidth: 1,
      padding: 10,
    },
  });
export default CustomerAdd;