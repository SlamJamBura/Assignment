import React, { useState } from 'react';
import { Button,  View } from 'react-native';
import Candle from './Candle';
const CandleApp = () => {
   const [candles,setCandles] = useState([
       {id:1, color:"green"},{id:2,color:"yellow"},{id:3,color:"pink"}
   ])
   let addCandle = (color)=>{
        setCandles([...candles,{color,id:Date.now()}]);
   }

   let deleteCandle = (id)=>{
        let records = candles.filter((item)=>(item.id != id));
        setCandles([...records]);
    }
  return (
    <View>
        {candles.map((item)=>(
            <Candle 
                key={item.id} 
                deleteRecord={()=>deleteCandle(item.id)} 
                color={item.color}/>
        ))}
        <Button title='RED' onPress={()=>{
            addCandle('red');
        }} /> 
        <Button title='PINK' onPress={()=>{
            addCandle('pink');
        }}/>
        <Button title='YELLOW' onPress={()=>{
            addCandle('yellow');
        }}/>
    </View>
  );
}

export default CandleApp;