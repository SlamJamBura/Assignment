import React, { useEffect, useState } from 'react';
import CustomerAdd from '../components/CustomerAdd';
import {View,Text} from 'react-native';
import Menu from '../components/AppMenu';
import { addCustomer, getCustomerById, updateCustomer } from '../service/CustomerAxios';
import { useNavigation } from '@react-navigation/native';
 
const AddCustomerComp = ({route}) => {
    const navigation = useNavigation();
    const[selectCustomer,setCustomer] = useState(null);
    const loadCustomer = async (customerId)=>{
        let customer = await getCustomerById(customerId);
        setCustomer(customer);
    }
    useEffect(()=>{
        if( route.params != undefined){
            console.log("route.params.id>>"+route.params.id);
            loadCustomer(route.params.id);
        }
    },[])
    return (
      <View>
        <Menu/>
        <Text>Add Customer</Text>
        <CustomerAdd selectCustomer={selectCustomer}
        addUpdateItem={async (customer)=>{
          if(customer.id == 0){
            customer.id= Date.now()+"d";
            await addCustomer(customer);
          }else{
            await updateCustomer(customer)
          }
          navigation.navigate("Customer");
      }}/>
      </View>
    );
  }
  export default AddCustomerComp;
