import React, { useEffect, useState } from 'react';
import { SafeAreaView,Button,FlatList, StyleSheet,StatusBar } from 'react-native';
import { addCustomer, getCustomers,deleteCustomer, getCustomerById, updateCustomer } from '../service/CustomerAxios';
import CustomerAdd from '../components/CustomerAdd';
import {CustomerItem} from '../components/CustomerItem';
import Menu from '../components/AppMenu';
import { useNavigation } from '@react-navigation/native';

// fetch , await, async | promise
// fetch new API by JavaScript Chrome, | native | 2018
// axios ajax thrid party | gives you all the header | data | caching / interceptor
// https://www.npmjs.com/package/axios

// promise example:
// https://vivek.pyther.com/new-horizon/rn/02-session/00-ecma-script/12-promise-await.js
const CustomerApp = () => {
  const navigation = useNavigation();
  const [customers,setCustomers] = useState([]); // only to render
  const [selectCustomer,setSelectCustomer] = useState(null); // only to render
  
  const reloadCustomers = async ()=>{
    console.log(">>reloadCustomers")
    let tempCustomers = await getCustomers();
    setCustomers([...tempCustomers]);
  }
  useEffect(()=>{
    const unsubscribe = navigation.addListener('focus', () => {
      reloadCustomers();
    });
    return unsubscribe;
  },[navigation]);


  const renderItem = ({ item }) => (
    <CustomerItem
        item={item}
        onPress={() => {}}
        style={{  }}
        onEdit = {async (id)=>{
          navigation.navigate('Update Customer', { id });
          
            //let editRecord = await getCustomerById(id);
            //setSelectCustomer(editRecord);
            //console.log(">> selectCustomer "+id);
            //deleteCustomer(id);
            //reloadCustomers();
        }}
        onDelete = {async (id)=>{
           await deleteCustomer(id);
            reloadCustomers();
        }}
      />
  );

  return (
    <SafeAreaView style={styles.container}>
      <Menu/>
      <Button onPress={()=>{
        navigation.navigate("Add Customer")
      }} title="Add"></Button>
      {/* <CustomerAdd selectCustomer={selectCustomer}
        addUpdateItem={async (customer)=>{
          if(customer.id == 0){
            customer.id= Date.now()+"d";
            await addCustomer(customer);
          }else{
            await updateCustomer(customer)
          }
          reloadCustomers();
      }}/> */}
      <FlatList
        data={customers}
        renderItem={renderItem}
        keyExtractor={item => item.id}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    marginTop: StatusBar.currentHeight || 0,
  },
  item: {
    backgroundColor: '#f9c2ff',
    padding: 20,
    marginVertical: 8,
    marginHorizontal: 16,
    flex:1,
    flexDirection:'column'
  },
  title: {
    fontSize: 32,
  },
  tinyLogo: {
    width: 30,
    height: 30,
  },
});

export default CustomerApp;