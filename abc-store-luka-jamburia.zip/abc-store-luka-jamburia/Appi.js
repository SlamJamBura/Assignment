import * as React from 'react';
import { View, Text } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import Login from './container/Login';
import Customer from './container/CustomerApp';
import ShirtApp from './container/ShirtListContainer';
import Menu from './components/AppMenu';
import AddCustomerComp from './container/AddCustomerCont';
import Constants from 'expo-constants';
import AssetExample from './components1/AssetExample';

function HomeScreen() {
  return (
    <View>
      <Menu/>
      <Text>Home Screen</Text>
    </View>
  );
}

function AboutScreen() {
  return (
    <View>
      <Menu/>
      <Text>About Screen</Text>
    </View>
  );
}

const Stack = createStackNavigator();
function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator>
      <Stack.Screen name="Login" component={Login} />
      <Stack.Screen name="Home" component={HomeScreen} />
      <Stack.Screen name="About" component={AboutScreen} />
      <Stack.Screen name="Shirts" component={ShirtApp} />
      <Stack.Screen name="Add Customer" component={AddCustomerComp} />
      <Stack.Screen name="Update Customer" component={AddCustomerComp} />
      <Stack.Screen name="Customer" component={Customer} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
export default App;