import * as React from 'react';
import { Text, View, StyleSheet } from 'react-native';
import Constants from 'expo-constants';
import App from "./Appi"
// You can import from local files
import AssetExample from './components1/AssetExample';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';


import { Card } from 'react-native-paper';

export default function Appa() {
  const Stack = createStackNavigator();
  return (

   <App/>
     
  
  );
}

