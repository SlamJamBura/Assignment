import * as React from 'react';
import { Text, View, StyleSheet } from 'react-native';
import Constants from 'expo-constants';
import AssetExample from './components/AssetExample';
import Index from "./index"
import { Card } from 'react-native-paper';
import { NavigationContainer } from '@react-navigation/native';
import {CreateStackNavigator} from "@react-navigation/stack";
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import Main from "./main"

export default function App() {
const Stack = createNativeStackNavigator();
  return (
    <div >
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen
          name="Index"
          component={Index}
          options={{ title: 'Welcome' }}
        />
        <Stack.Screen name="Main" component={Main} options ={{tittle:"Main"}} />
      </Stack.Navigator>
    </NavigationContainer>
    
    </div>
  );
}


