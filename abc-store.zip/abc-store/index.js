import * as React from 'react';
import { Text, View, StyleSheet,Button } from 'react-native';
import Constants from 'expo-constants';
import { NavigationContainer } from '@react-navigation/native';
import {CreateStackNavigator} from "@react-navigation/stack";
import { createNativeStackNavigator } from '@react-navigation/native-stack';
// You can import from local files
import AssetExample from './components/AssetExample';

// or any pure javascript modules available in npm
import { Card } from 'react-native-paper';
const body = {
  color:"#4169E1",
  fontSize:25,
    textAlign:"center",
    margin: 0,  
    paddingBottom: 180,  
    backgroundColor:"#00CED1" ,

}
const all={
  backgroundColor:"#F8F8FF",
}
const hash = {
  color:"#4169E1",
  margin:35,
    padding: 20,  
    backgroundColor:"#00CED1" ,
}
export default function Index ({navigation}){

  return (
    <div style={all} >
    <Text style={styles.paragraph}><h2 style={hash} >Login Page </h2></Text>
    <body style={body} >
    <div className="login">
<form id="login" method="get" action="login.php">    
        <label><b>User Name     
        </b>    
        </label>    
        <input type="text" name="Uname" id="Uname" placeholder="Username"/>    
        <br></br>    
        <label><b>Password     
        </b>    
        </label>    
        
   <input type="Password" name="Pass" id="Pass" placeholder="Password" />
         
        <br></br>    
      
     <input type="button" name="log" id="log" value="Log In Here" onClick={() => navigation.push("Main")} />   
     
        <br></br>    
        <input type="checkbox" id="check"/>    
        <span>Remember me</span>    
        <br></br>    
        Forgot <a href="#">Password</a>    
    </form>   
    </div>
    </body>
    </div>
  );
}
const styles = StyleSheet.create({

  paragraph: {
    margin: 124,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});