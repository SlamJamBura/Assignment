import * as React from 'react';
import { Text, View, StyleSheet } from 'react-native';
import Constants from 'expo-constants';
import AssetExample from './components/AssetExample';
import Index from "./index"
import { Card } from 'react-native-paper';
import { NavigationContainer } from '@react-navigation/native';
import {CreateStackNavigator} from "@react-navigation/stack";
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import img from "./download.jfif"
const k={
float:"center",
marginLeft:30,

}
const e={
position:"relative",
}
const aa={
position:"absolute",
textAlign:"Left",
bottom:94,
left:45,
color:"#1e90ff"
}
const aaa={
position:"absolute",
textAlign:"center",
bottom:39,
left:180,
  backgroundColor: "#1899D6",
  borderRadius:30,
  fontSize:18,
  
}
const d={
  display:"inline",
  listStyle:"none",
  marginTop:0,
  marginLeft:15,
 
fontSize:20,
}
export default function Main() {
return(
<div>
<nav></nav>
<nav></nav>
<h1>Categories</h1>
<nav>
<ul style={k}>

<li style={d}>apparel</li>
<li style={d}>beauty</li>
<li style={d}>shoes</li>
<li style={d}>other</li>

</ul>
</nav>
<h1>Latest</h1>
<div style={e}>
<img src={img} style={s}/>
<h1 style={aa}>Summer T-shirts </h1>
<button style={aaa}>SEE MORE </button>
</div>
<div>
<ul style={st}>
<li style={bo}>home</li>
<li style={bo}>search</li>
<li style={bo}>cart</li>
<li style={bo}>profile</li>
<li style={bo}>more</li>
</ul>
</div>
</div>
);
}
const st={
   position: "fixed",
     bottom: 0,
     right: 0,
  paddingRight:130,
  width:170,
  height:40,
  backgroundColor:"grey",
textAlign:"left",
  borderColor:"red",
  

}
const bo={
 

color:"#00CED1",
   display:"inline",
  listStyle:"none",
  marginTop:30,
  marginLeft:15,


fontSize:20,
  
}
const s={
  borderRadius:60,
  marginLeft:25,
  width:285,
  height:180,
}
